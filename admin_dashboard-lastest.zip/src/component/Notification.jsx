import React from 'react'

function Notification() {
  return (
  //   <Dropdown>
  //   <Dropdown.Toggle className="bg-transparent border-0 mt-4 flex items-center justify-center" id="dropdown-basic">
  //   <Link
  //     className="nav-link nav-profile d-flex align-items-center pe-0"
  //     href="#"
  //     data-bs-toggle="dropdown"
  //   >
  //     <img src={prfile} alt="Profile" className="rounded-circle" />
  //     <span className="d-none d-md-block dropdown-toggle ps-2">
  //       K. Anderson
  //     </span>
  //   </Link>
  //   </Dropdown.Toggle>

  //   <Dropdown.Menu>
  //   <div>
  //   <h2>Zia</h2>
  //   </div>
  //   </Dropdown.Menu>
  // </Dropdown>
  <div></div>
  )
}

export default Notification
