import React from "react";

function ApiReviews() {
  return (
    <tr>
      <td className="py-2">joe</td>
      <td className="py-2">5</td>
      <td className="py-2">nice</td>
      <td className="py-2">test@admin.com</td>
      <td className="py-2">
        <button
          className="bg-red-600 rounded-lg px-3 py-2 text-white"
        >
          Delete
        </button>
      </td>
    </tr>
  );
}

export default ApiReviews;
