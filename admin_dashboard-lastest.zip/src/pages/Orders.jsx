import React from 'react'
import OrdersTable from '../component/dashboard/OrdersTable'

function Orders() {
  return (
 
    <OrdersTable/>
  )
}

export default Orders
