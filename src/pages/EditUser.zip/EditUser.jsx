import React, { useState } from "react";
import profile from ".././images/messages-3.jpg";
import { Form } from "react-bootstrap";

function EditUser() {

    const [name, setname] = useState("David");
    const [last, setlast] = useState("joe");
    const [email, setemail] = useState("david.joe12@gmail.com");
    const [numb, setnumb] = useState("91 313 4556");
    const [address, setaddress] = useState("street no : 124 abc town ,  usa");
    


  return (
    <main>
      <h1>Edit User</h1>
      <div className="bg-white shadow-lg rounded-lg p-4 my-3">
        <div className="row items-center">
          <div className="col-lg-4 col-sm-12">
            <img
              src={profile}
              width={100}
              height={130}
              alt="+"
              className="rounded-full broder-[#2f007e] border-2"
            />
          </div>
        </div>
        <div className="row mt-5">
          <div className="col-lg-6 col-sm-12">
            <Form.Label htmlFor="name" className="text-2xl">
              first name
            </Form.Label>
            <Form.Control
              type="text"
              id="name"
              aria-describedby="passwordHelpBlock"
              className="py-3 text-xl"
              value={name}
              onChange={(e)=>setname(e.target.value)}
            />
          </div>
          <div className="col-lg-6 col-sm-12">
            <Form.Label htmlFor="name" className="text-2xl">
              last name
            </Form.Label>
            <Form.Control
              type="text"
              id="name"
              aria-describedby="passwordHelpBlock"
              className="py-3 text-xl"
              value={last}
              onChange={(e)=>setlast(e.target.value)}
            />
          </div>
        </div>
        <div className="row my-3">
          <div className="col-lg-6 col-sm-12">
            <Form.Label htmlFor="name" className="text-2xl">
              Email
            </Form.Label>
            <Form.Control
              type="email"
              id="name"
              aria-describedby="passwordHelpBlock"
              className="py-3 text-xl"
              value={email}
              onChange={(e)=>setemail(e.target.value)}
            />
          </div>
          <div className="col-lg-6 col-sm-12">
            <Form.Label htmlFor="name" className="text-2xl">
              phone number
            </Form.Label>
            <Form.Control
              type="text"
              id="name"
              aria-describedby="passwordHelpBlock"
              className="py-3 text-xl"
              value={numb}
              onChange={(e)=>setnumb(e.target.value)}
            />
          </div>
        </div>
        <div className="row my-3">
          <div className="col-12">
            <Form.Label htmlFor="name" className="text-2xl">
              Address
            </Form.Label>
            <Form.Control
              type="text"
              id="name"
              aria-describedby="passwordHelpBlock"
              className="py-3 text-xl "
              value={address}
              onChange={(e)=>setaddress(e.target.value)}
            />
          </div>
        </div>
        <div className="row items-center">
          <div className="col-lg-6 col-sm-12">
            <Form.Label htmlFor="name" className="text-2xl">
              Status
            </Form.Label>
            <Form.Select aria-label="Default select example" className="py-4">
              
              <option value="1" defaultChecked>Active</option>
              <option value="2">Deactive</option>
            </Form.Select>
          </div>
          <div className="col-lg-6 col-sm-12">
          <button className="bg-[#2f007e] text-white rounded-md shadow-lg px-5 py-4 mt-[35px]  w-full ">Update</button>
          </div>
        </div>
      </div>
    </main>
  );
}

export default EditUser;
